% Outputs:  (1) r: steady state interest rate
%           (2) w: steady state wage
%           (3) K: capital stock
%           (4) A: matrix for computing value function
%           (5) u: utility over grid
%           (5) c: consumption over grid
%           (6) V: value function over grid
%			(7) g: distribution
%           (8) dV_Upwind: derivative of value function by upwind scheme
%           (9) dVf: derivative of value function by forward difference
%           (10) dVb: derivative of value function by backward difference
%           (11) If: indicator for forward drift in savings
%           (12) Ib: indicator for backward drift in savings
%           (13) I0: indicator for no drift in savings

function [r,w,K,A,u,c,V,g,dV_Upwind,dVf,dVb,If,Ib,I0,lsupply] = compute_ss_ourcodes()
tic ;
% create structure with structural parameters
call_parameters;
% create structure with numerical parameters
numerical_parameters ;
% create structure with grids and initial guesses for v
grid = create_grid(param,num) ;

%error = @(r) excess_demand(r,param,num,grid);

r_initial=0.01;

r=fminsearch(@excess_demand,r_initial);

w=(1-param.alpha)*(param.alpha/(r+param.delta))^(param.alpha/(1-param.alpha));

[grid] = create_grid(param,num);

[c,~,lsupply,~,V,A,dV_Upwind,dVf,dVb,If,Ib,I0,~,~]=hh_problem(r,w,param,num,grid);

%[~,~,lsupply,~]=hh_problem(r,w,param,num,grid);

[K]=firm_problem(lsupply,r,w,param,num,grid);

u = utility(c);

[gg] = kf_equation(A,grid,num);
g=[gg(1:num.a_n),gg(num.a_n+1:2*num.a_n)];


toc ;
end 