param.e = [0.1 0.2] ;
param.ret = [1.05 0.95];
param.rho = 0.03 ;
param.lambda = [0.1 0.1] ;
param.delta = 0.05 ;
param.alpha = 0.35 ;