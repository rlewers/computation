function out = numel(x)
  % by SeHyoun Ahn, July 2016
  out= numel(x.values);
end
