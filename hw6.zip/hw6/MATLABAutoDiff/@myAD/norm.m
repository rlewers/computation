function [output] = norm(x)
  output = sum(x.^2).^0.5;
end
