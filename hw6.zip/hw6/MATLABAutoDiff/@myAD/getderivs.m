function Jac = getderivs(x)
  % In Package myAD - Automatic Differentiation
  % by Martin Fink, June 2006
  % martinfink 'at' gmx.at
  Jac = x.derivatives;
end
