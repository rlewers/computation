function x = swapval(x, val_in)
  x.values = val_in;
end