function x=reshape(x,varargin)
  % by SeHyoun Ahn, Jan 2016
  x.values=reshape(x.values,varargin{:});
end
