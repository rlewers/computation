function A = full(A);
% by SeHyoun Ahn, Oct 2017

% This function does not support all use cases of find.

  A.values = full(A.values);
end
