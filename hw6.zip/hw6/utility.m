function u = utility(c)

u = log(c) ;
end