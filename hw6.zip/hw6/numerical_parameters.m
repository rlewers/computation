num.Delta = 0.5 ;
num.a_n = 100 ;
num.a_min = 0 ;
num.a_max = 7 ;
num.tol = 1e-7 ;

